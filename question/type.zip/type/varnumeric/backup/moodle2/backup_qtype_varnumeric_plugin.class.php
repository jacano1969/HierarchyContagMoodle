<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * @package    moodlecore
 * @subpackage backup-moodle2
 * @copyright  2011 The Open University
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */


defined('MOODLE_INTERNAL') || die();


/**
 * Provides the information to backup varnumeric questions
 *
 * @copyright  2011 The Open University
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class backup_qtype_varnumeric_plugin extends backup_qtype_plugin {

    /**
     * Returns the qtype information to attach to question element
     */
    protected function define_question_plugin_structure() {

        // Define the virtual plugin element with the condition to fulfill
        $plugin = $this->get_plugin_element(null, '../../qtype', 'varnumeric');

        // Create one standard named plugin element (the visible container)
        $pluginwrapper = new backup_nested_element($this->get_recommended_name());

        // connect the visible container ASAP
        $plugin->add_child($pluginwrapper);

        // This qtype uses standard question_answers, add them here
        // to the tree before any other information that will use them
        $this->add_question_question_answers($pluginwrapper);

        //extra answer fields for varnumeric question type
        $this->add_question_qtype_varnumeric_answers($pluginwrapper);

        $this->add_question_qtype_varnumeric_vars($pluginwrapper);

        // Now create the qtype own structures
        $varnumeric = new backup_nested_element('varnumeric', array('id'), array(
            'randomseed', 'recalculateeverytime', 'requirescinotation'));

        // Now the own qtype tree
        $pluginwrapper->add_child($varnumeric);

        // set source to populate the data
        $varnumeric->set_source_table('qtype_varnumeric',
                array('questionid' => backup::VAR_PARENTID));

        // don't need to annotate ids nor files

        return $plugin;
    }

    protected function add_question_qtype_varnumeric_vars($element) {
        // Check $element is one nested_backup_element
        if (! $element instanceof backup_nested_element) {
            throw new backup_step_exception('qtype_varnumeric_vars_bad_parent_element', $element);
        }

        // Define the elements
        $vars = new backup_nested_element('vars');
        $var = new backup_nested_element('var', array('id'),
                                                array('varno', 'nameorassignment'));

        $this->add_question_qtype_varnumeric_variants($var);

        // Build the tree
        $element->add_child($vars);
        $vars->add_child($var);

        // set source to populate the data
        $var->set_source_table('qtype_varnumeric_vars',
                                                array('questionid' => backup::VAR_PARENTID));
    }

    protected function add_question_qtype_varnumeric_variants($element) {
        // Check $element is one nested_backup_element
        if (! $element instanceof backup_nested_element) {
            throw new backup_step_exception('qtype_varnumeric_variants_bad_parent_element',
                                                                                        $element);
        }

        // Define the elements
        $variants = new backup_nested_element('variants');
        $variant = new backup_nested_element('variant', array('id'),
                                                array('varid', 'variantno', 'value'));

        // Build the tree
        $element->add_child($variants);
        $variants->add_child($variant);

        // set source to populate the data
        $variant->set_source_table('qtype_varnumeric_variants',
                                                array('varid' => backup::VAR_PARENTID));
    }
    protected function add_question_qtype_varnumeric_answers($element) {
        // Check $element is one nested_backup_element
        if (! $element instanceof backup_nested_element) {
            throw new backup_step_exception('question_varnumeric_answers_bad_parent_element',
                                                $element);
        }

        // Define the elements
        $answers = new backup_nested_element('varnumeric_answers');
        $answer = new backup_nested_element('varnumeric_answer', array('id'), array(
            'answerid', 'error', 'sigfigs', 'checknumerical', 'checkscinotation',
            'checkpowerof10', 'checkrounding', 'syserrorpenalty'));

        // Build the tree
        $element->add_child($answers);
        $answers->add_child($answer);

        // Set the sources
        $answer->set_source_sql('
                SELECT vans.*
                FROM {question_answers} AS ans, {qtype_varnumeric_answers} AS vans
                WHERE ans.question = :question AND ans.id = vans.answerid
                ORDER BY id',
                array('question' => backup::VAR_PARENTID));
        // don't need to annotate ids nor files
    }
}
