# Metadata

Metadata is loosely defined as data about data.
These fields enable you to record some information about your question.