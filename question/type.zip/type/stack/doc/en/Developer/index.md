# Developer

If you want to track the development of STACK or report bugs then you should visit [github](https://github.com/maths/moodle-qtype_stack).

Work towards the next release of STACK is detailed on [Development track](Development_track.md).

Plans looking futher into the future are described on [Future plans](Future_plans.md).

The past development history is documented on [Development history](Development_history.md).

Please use the site map to navigate other developer pages.
